<?php include "inc/header.php"?>
<?php
	if(!isset($_GET['search']) || $_GET['search'] == NULL){
		header('location: 404.php');
	}else{
		$search =	$_GET['search'];
	}
?>
</div>
	<div class="contentsection contemplete clear">
		<div class="maincontent clear">

    
		<?php 
			$sql = "SELECT * FROM tbl_post WHERE title LIKE '%$search%' or body LIKE '%$search%'";
			$post = $db->select($sql);
			if($post){
				while($result = $post->fetch_assoc()){
					?>
					
			<div class="samepost clear">
				<h2><a href="post.php?id=<?= $result['id']?>"><?= $result['title']?></a></h2>
				<h4><?= $fm->formatDate($result['date'])?> <a href="#"><?= $result['author']?></a></h4>
				 <a href="#"><img src="admin/upload/<?= $result['image']?>" alt="post image"/></a>
				 <?= $fm->textShorten($result['body'])?>
				<div class="readmore clear">
					<a href="post.php?id=<?= $result['id']?>">Read More</a>
				</div>
			</div>
      <?php } }else{echo "no data found";}?> <!--end of while-->
        

		</div>
		<?php include "inc/sidebar.php"?>
	</div>

	<?php include "inc/footer.php"?>