<div class="slidersection templete clear">
        <div id="slider">
            <?php
            $query = "SELECT * FROM tbl_slider order by id limit 5";
            $post = $db->select($query);
            if($post){
            while($post_result = $post->fetch_assoc()){
            ?>
            
            <a href="#"><img style="object-fit: cover; width: 100%;" height="300px" src="admin/upload/slider/<?= $post_result['image']?>" alt="nature 1" title="<?= $post_result['slider_title']?>" /></a>
            <?php } }?>
        </div>
