<?php

class Session {
  //start session
  public static function init(){
    session_start();
  }
  //set session
  public static function set($key, $value){
   $_SESSION[$key] = $value;
  }
  //get session
  public static function get($key){
    if(isset($_SESSION[$key])){
      return $_SESSION[$key];
    }else {
      return false;
    }

  }
  //check session
  public static function checkSession(){
    self::init();
    if(self::get("login") == false){
      self::destroy();
      header('location: login.php');
    }
  }

  public static function destroy(){
    session_destroy();
    header('location: login.php');
  }
}