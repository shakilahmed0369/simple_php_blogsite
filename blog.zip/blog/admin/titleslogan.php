﻿<?php include "inc/header.php"?>
<style>
    .left-side {
        float: left;
        width: 70%;
    }
    .right-side {
        float: left;
        width: 30%;
    }
</style>


        <div class="grid_10">
        

            <div class="box round first grid">
                <h2>Update Site Title and Description</h2>
                <?php
                    if(isset($_REQUEST['submit'])){
                        $title  = $_REQUEST['title'];
                        $slogan    = $_REQUEST['slogan'];
                       

                        $file_name = $_FILES['logo']['name'];
                        $file_temp = $_FILES['logo']['tmp_name'];
                        $Logo_name = 'logo.png';
                        

                        if(empty($title) || empty($slogan)){
                            echo "<span style='color: red;'>field must not be empty</span>";
                        }elseif(!empty($file_name)){

                            move_uploaded_file($file_temp, 'upload/logo/'.$Logo_name);
                            $query = "UPDATE title_slogan SET
                                title  = '$title',
                                slogan = '$slogan'
                                WHERE id = 1";
                            $updated_row = $db->update($query);
                            if($updated_row){
                                echo "<span style='color: green;'>Post Update successfully</span>";
                            }else{
                                echo "<span style='color: red;'>Post Update Unsuccess</span>";

                            }

                        }else {
                            $query = "UPDATE title_slogan SET
                                title  = '$title',
                                slogan = '$slogan'
                                WHERE id = 1";
                            $updated_row = $db->update($query);
                            if($updated_row){
                                echo "<span style='color: green;'>Post Update successfully</span>";
                            }else{
                                echo "<span style='color: red;'>Post Update Unsuccess</span>";

                            }
                        }
                    }
                
                ?>
                <div class="block sloginblock">    
                <?php 
                $query = "SELECT * FROM title_slogan WHERE id = 1";
                $update = $db->select($query);
                if($update){
                    while($result = $update->fetch_assoc()){
                ?>
                  
                    <div class="left-side">          
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">					
                        <tr>
                            <td>
                                <label>Website Title</label>
                            </td>
                            <td>
                                <input type="text" value="<?= $result['title']?>"  name="title" class="medium" />
                            </td>
                        </tr>
						 <tr>
                            <td>
                                <label>Website Slogan</label>
                            </td>
                            <td>
                                <input type="text" value="<?= $result['slogan']?>" name="slogan" class="medium" />
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label>Website Logo</label>
                            </td>
                            <td>
                                <input type="file" name="logo" class="medium" />
                            </td>
                        </tr>
						 <tr>
                            <td>
                            </td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    </div>

                    <div class="right-side">
                        <img height="300px" width="300px" src="upload/logo/<?= $result['logo']?>" alt="logo" srcset="">
                    </div>
                </div>
            </div>
            <?php  } }?>
        </div>
        <?php include "inc/footer.php"?>