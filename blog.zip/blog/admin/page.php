<?php include "inc/header.php"?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Post</h2>
                <?php
                  if(isset($_REQUEST['id'])){
                    $id = $_REQUEST['id'];
                  }
                    
                  if(isset($_REQUEST['submit'])){
                   $name  = $_REQUEST['name'];
                   $body  = $_REQUEST['body'];
                    if(empty($name) || empty($body)){
                        echo "<span style='color: red;'>field must not be empty</span>";
                    }else{
                        $query = "UPDATE tbl_page SET name = '$name', body = '$body' WHERE id = $id";
                
                        $updated_row = $db->update($query);
                        if($updated_row){
                            echo "<span style='color: green;'>Page Update successfully</span>";
                        }else{
                            echo "<span style='color: red;'>Page Update Unsuccess</span>";
                        }
                    }
                
                }
                
                ?>
                <div class="block">  
                <?php
                $query = "SELECT * FROM tbl_page WHERE id=$id";
                $pages = $db->select($query);
                if($pages){
                while($result = $pages->fetch_object()){
                ?>             
                 <form action="" method="POST">
                    <table class="form">
                        <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input name="name" type="text" value="<?= $result->name ?> " class="medium" />
                            </td>
                        </tr>
                     
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea name="body" class="tinymce"><?= $result->body?></textarea>
                            </td>
                        </tr>

						            <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                                <span style="margin-left: 10px;border: 1px solid #ddd;color: #444;cursor: pointer;font-size: 17px;;padding: 4px 10px;   " class="actiondel"><a onclick="return confirm('are you sure?')" href="delpage.php?delpage=<?=$result->id?>">Delete</a></span>
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php } } ?>
                </div>
            </div>
        </div>
        <!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
    $(document).ready(function () {
    setupTinyMCE();
    setDatePicker('date-picker');
    $('input[type="checkbox"]').fancybutton();
    $('input[type="radio"]').fancybutton();
    });
    </script>
<?php include "inc/footer.php"?>
