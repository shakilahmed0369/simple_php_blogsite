<?php include "inc/header.php"?>
<?php 
  if(!isset($_REQUEST['catid']) || $_REQUEST['catid'] == NULL){
    header('localhost: catlist.php');
  }else{
    $id = $_REQUEST['catid'];
  }
?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Category</h2>
               <div class="block copyblock"> 
                   <?php
                    if(isset($_REQUEST['submit'])){
                        $name = $_REQUEST['name'];
                        if(empty($name)){
                            echo "<span style='color: red;'>field must not be empty</span>";
                        }else{
                            $query = "UPDATE tbl_catagory SET name = '$name' WHERE id = $id";
                            $update = $db->insert($query);
                            if($update){
                                echo "<span style='color: green;'>Category Updated successfully</span>";
                            }else{
                                echo "<span style='color: green;'>Category not Updated</span>";
                            }
                        }
                    }
                   ?>
                   <?php
                    $query = "SELECT * FROM tbl_catagory WHERE id = $id order by id desc";
                    $category = $db->select($query);
                    $category = $category->fetch_array();
                    
                   
                   ?>
                 <form action="" method="POST">
                    <table class="form">					
                        <tr>
                            <td>
                                <input value="<?= $category['name']?>" name="name" type="text" placeholder="Enter Category Name..." class="medium" />
                            </td>
                        </tr>
						<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
 <?php include "inc/footer.php"?>