<?php include "inc/header.php"?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Post</h2>
                <?php
                    if(isset($_REQUEST['submit'])){
                        $name  = $_REQUEST['name'];
                        $body    = $_REQUEST['body'];

                        

                        if(empty($name) || empty($body)){
                            echo "<span style='color: red;'>field must not be empty</span>";
                        }else{
                            $query = "INSERT INTO tbl_page(name, body) VALUES('$name','$body')";
                            $create = $db->insert($query);
                            if($create){
                                echo "<span style='color: green;'>Page created successfully</span>";
                            }else{
                                echo "<span style='color: red;'>Page  Not created</span>";
                            }
                        }
                    }
                
                ?>
                <div class="block">               
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input name="name" type="text" placeholder="Enter Post Title..." class="medium" />
                            </td>
                        </tr>
                     
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea name="body" class="tinymce"></textarea>
                            </td>
                        </tr>

						            <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Create" />
                               
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
        <!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
    $(document).ready(function () {
    setupTinyMCE();
    setDatePicker('date-picker');
    $('input[type="checkbox"]').fancybutton();
    $('input[type="radio"]').fancybutton();
    });
    </script>
<?php include "inc/footer.php"?>
