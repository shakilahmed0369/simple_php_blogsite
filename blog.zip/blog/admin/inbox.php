﻿<?php include "inc/header.php"?>



        <div class="grid_10">
            <div class="box round first grid">
								<h2>Inbox</h2>
								<?php
if(isset($_REQUEST['delid'])){
	$delid = $_REQUEST['delid'];
	$qurey = "DELETE FROM tbl_contact WHERE id = $delid";
	$delete = $db->update($qurey);
	if($delete){
		echo "<span style='color: green;'>Message deleted</span>";
	}else{
		echo "<span style='color: red;'>Somthing wents worng</span>";
	}
}

?>
<?php
if(isset($_REQUEST['seenid'])){
	$seenid = $_REQUEST['seenid'];
	$qurey = "UPDATE tbl_contact SET status='1' WHERE id= $seenid";
	$seen = $db->update($qurey);
	if($seen){
		echo "<span style='color: green;'>Message send in to seen box</span>";
	}else{
		echo "<span style='color: red;'>Somthing wents worng</span>";
	}
}
?>
                <div class="block">
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Name</th>
							<th>Email</th>
							<th>Message</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
					<?php 
							$query = "SELECT * FROM tbl_contact WHERE status = 0";
							$contact = $db->select($query);
							if($contact){
								$i=0;
								while($result = $contact->fetch_assoc()){
								$i++;
								?>
						<tr class="odd gradeX">
							<td><?= $i;?></td>
							<td><?= $result['firstname']." "; echo $result['lastname']?></td>
							<td><?= $result['email'] ?></td>
							<td><?= $fm->textShorten($result['body'], 30) ?></td>
							<td><?= $fm->formatDate($result['date']) ?></td>
							<td>
								<a href="viewmsg.php?msgid=<?= $result['id']?>">View</a> ||
								<a href="replaymsg.php?msgid=<?= $result['id']?>">Replay</a> ||
								<a href="?seenid=<?= $result['id']?>">Seen</a>
								</td>
						</tr>
						<?php
								}
							}
						?>
						
					</tbody>
				</table>
               </div>
						</div>
						<div class="box round first grid">
                <h2>Inbox</h2>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Name</th>
							<th>Email</th>
							<th>Message</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
					<?php 
							$query = "SELECT * FROM tbl_contact WHERE status = 1";
							$contact = $db->select($query);
							if($contact){
								$i=0;
								while($result = $contact->fetch_assoc()){
								$i++;
								?>
						<tr class="odd gradeX">
							<td><?= $i;?></td>
							<td><?= $result['firstname']." "; echo $result['lastname']?></td>
							<td><?= $result['email'] ?></td>
							<td><?= $fm->textShorten($result['body'], 30) ?></td>
							<td><?= $fm->formatDate($result['date']) ?></td>
							<td>
								
								<a href="?delid=<?= $result['id']?>">Delete</a>
								</td>
						</tr>
						<?php
								}
							}
						?>
						
					</tbody>
				</table>
               </div>
						</div>
				</div>
				

				
        
<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();

        $('.datatable').dataTable();
        setSidebarHeight();
    });
</script>
        <?php include "inc/header.php"?>