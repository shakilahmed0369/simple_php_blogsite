﻿<?php include "inc/header.php"?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Social Media</h2>
                <div class="block">  
<?php
if(isset($_REQUEST['submit'])){
    $facebook  = $_REQUEST['facebook'];
    $twitter  = $_REQUEST['twitter'];
    $linkedin  = $_REQUEST['linkedin'];
    $googleplus  = $_REQUEST['googleplus'];
    
   

    if(empty($facebook) || empty($twitter) || empty($linkedin) || empty($googleplus)){
        echo "<span style='color: red;'>field must not be empty</span>";
    }else{
        $query = "UPDATE tbl_social SET
            fb  = '$facebook',
            tw  = '$twitter',
            ln  = '$linkedin',
            gp  = '$googleplus'
            WHERE id = 1";

        $updated_row = $db->update($query);
        if($updated_row){
            echo "<span style='color: green;'>Post Update successfully</span>";
        }else{
            echo "<span style='color: red;'>Post Update Unsuccess</span>";

        }
    }

}
                    
?>          
                 <form action="" method="POST">
                    <table class="form">	
                <?php 
                $query = "SELECT * FROM tbl_social WHERE id = 1";
                $update = $db->select($query);
                if($update){
                    while($result = $update->fetch_assoc()){
                ?>	

                        <tr>
                            <td>
                                <label>Facebook</label>
                            </td>
                            <td>
                                <input type="text" name="facebook" value="<?= $result['fb']?>" class="medium" />
                            </td>
                        </tr>
						 <tr>
                            <td>
                                <label>Twitter</label>
                            </td>
                            <td>
                                <input type="text" name="twitter" value="<?= $result['tw']?>" class="medium" />
                            </td>
                        </tr>
						
						 <tr>
                            <td>
                                <label>LinkedIn</label>
                            </td>
                            <td>
                                <input type="text" name="linkedin" value="<?= $result['ln']?>" class="medium" />
                            </td>
                        </tr>
						
						 <tr>
                            <td>
                                <label>Google Plus</label>
                            </td>
                            <td>
                                <input type="text" name="googleplus" value="<?= $result['gp']?>" class="medium" />
                            </td>
                        </tr>
						
						 <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                <?php } } ?>		

                    </form>
                </div>
            </div>
        </div>
        <?php include "inc/footer.php"?>