
<?php include "inc/header.php"?>			 
			 <div class="grid_10">
            <div class="box round first grid">
								<h2>Category List</h2>
								<?php 
									if(isset($_REQUEST['delid'])){
										$delid = $_REQUEST['delid'];
										$delquery = "DELETE FROM tbl_slider WHERE id = $delid";
										$delcat = $db->delete($delquery);
										if($delcat){
											echo "<span style='color: green;'>Slider Deleted successfully</span>";
										}else{
											echo "<span style='color: green;'>Slider not Deleted</span>";
									}
									}
								?>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Slider Title</th>
							<th>Slider image</th>
							<th>Acton</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$query = "SELECT * FROM tbl_slider ORDER BY id DESC";
							$slider = $db->select($query);
							if($slider){
								$i=0;
								while($result = $slider->fetch_assoc()){
								$i++;
								?>
										<tr class="odd gradeX">
											<td><?= $i ?></td>
											<td><?= $result['slider_title']?></td>
											<td><img width="100px" src="upload/slider/<?= $result['image']?>" alt=""></td>
											<td><a href="editslider.php?editid=<?=$result['id']?>">Edit</a> || <a href="?delid=<?=$result['id']?>" onclick="return confirm('are you sure?')">Delete</a></td>
										</tr>

								<?php
								}
							}
						?>

					</tbody>
				</table>
               </div>
            </div>
				</div>

<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();

        $('.datatable').dataTable();
        setSidebarHeight();
    });
</script>

<?php include "inc/footer.php"?>

