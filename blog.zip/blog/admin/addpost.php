﻿<?php include "inc/header.php"?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Post</h2>
                <?php
                    if(isset($_REQUEST['submit'])){
                        $title  = $_REQUEST['title'];
                        $cat    = $_REQUEST['cat'];
                        $body   = $_REQUEST['body'];
                        $tags   = $_REQUEST['tags'];
                        $author = $_REQUEST['author'];
                        $userid = $_REQUEST['userid'];

                        $file_name = $_FILES['image']['name'];
                        $file_temp = $_FILES['image']['tmp_name'];
                        $uniq_name = uniqid().'.jpg';
                        

                        if(empty($title) || empty($cat) || empty($body) || empty($tags) || empty($author) || empty($file_name)){
                            echo "<span style='color: red;'>field must not be empty</span>";
                        }else{
                            move_uploaded_file($file_temp, 'upload/'.$uniq_name);
                            $query = "INSERT INTO tbl_post(cat, title, body, image, author, tags,userid) VALUES('$cat','$title','$body','$uniq_name','$author','$tags','$userid')";
                            $insert = $db->insert($query);
                            if($insert){
                                echo "<span style='color: green;'>Post insurt successfully</span>";
                            }else{
                                echo "<span style='color: red;'>Post insurt Unsuccess</span>";

                            }

                        }


                    }
                
                ?>
                <div class="block">               
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input name="title" type="text" placeholder="Enter Post Title..." class="medium" />
                            </td>
                        </tr>
                     
                        <tr>
                            <td>
                                <label>Category</label>
                            </td>
                            <td>
                                <select name="cat" id="select" name="select">
                                    <option>Select Catagory</option>
                                    <?php
                                     $query = "SELECT * FROM tbl_catagory";
                                     $category = $db->select($query);
                                     if($category){
                                         while($result = $category->fetch_assoc()){
                                             ?>

                                    <option value="<?= $result['id']?>"><?= $result['name']?></option>

                                    <?php
                                         }
                                     }
                                    ?>

                                </select>
                            </td>
                        </tr>
                   
                        <tr>
                            <td>
                                <label>Upload Image</label>
                            </td>
                            <td>
                                <input name="image" type="file" />
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea name="body" class="tinymce"></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>tags</label>
                            </td>
                            <td>
                                <input name="tags" type="text" placeholder="tags" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Author</label>
                            </td>
                            <td>
                                <input name="author" type="text" value="<?= Session::get('username')?>" placeholder="author name" class="medium" />
                                <input name="userid" type="hidden" value="<?= Session::get('userid')?>" placeholder="author name" class="medium" />
                            </td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
        <!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
    $(document).ready(function () {
    setupTinyMCE();
    setDatePicker('date-picker');
    $('input[type="checkbox"]').fancybutton();
    $('input[type="radio"]').fancybutton();
    });
    </script>
<?php include "inc/footer.php"?>
