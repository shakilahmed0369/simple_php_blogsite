<?php include "inc/header.php"?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Post</h2>
                <?php
                $id = $_REQUEST['editid'];
                    if(isset($_REQUEST['submit'])){
                        $title  = $_REQUEST['title'];
                        $file_name = $_FILES['image']['name'];
                        $file_temp = $_FILES['image']['tmp_name'];
                        $uniq_name = uniqid().'.jpg';
                        

                        if(empty($title)){
                            echo "<span style='color: red;'>field must not be empty</span>";
                        }elseif(!empty($file_name)){
                          move_uploaded_file($file_temp, 'upload/slider/'.$uniq_name);
                          $query = "UPDATE tbl_slider SET
                          slider_title  = '$title',
                          image  = '$uniq_name'
                          WHERE id = '$id'
                      ";
                      $updated_row = $db->update($query);
                          if($updated_row){
                              echo "<span style='color: green;'>Slider Update successfully</span>";
                          }else{
                              echo "<span style='color: red;'>Slider Update Unsuccess</span>";
                          }
                        }else{
                          $query = "UPDATE tbl_slider SET
                          slider_title  = '$title'
                          WHERE id = '$id'
                      ";
                      $updated_row = $db->update($query);
                          if($updated_row){
                              echo "<span style='color: green;'>Slider Update successfully</span>";
                          }else{
                              echo "<span style='color: red;'>Slider Update Unsuccess</span>";
                          }

                        }
                    }
                
                ?>
                <div class="block">               
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Slider Title</label>
                            </td>

<?php
$query = "SELECT * FROM tbl_slider where id='$id'";
$post = $db->select($query);
if($post){
while($post_result = $post->fetch_array()){
?>
                        <td>
                          <img width="300px" src="upload/slider/<?= $post_result['image']?>" alt=""><br>
                          <input name="title" type="text" value="<?= $post_result['slider_title']?>" placeholder="Enter Slider Title..." class="medium" />
                        </td>
<?php } } ?>
                        </tr>
                   
                        <tr>
                            <td>
                                <label>Slider Image</label>
                            </td>
                            <td>
                                <input name="image" type="file" class="medium" />
                            </td>
                        </tr>


						            <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
        <!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
    $(document).ready(function () {
    setupTinyMCE();
    setDatePicker('date-picker');
    $('input[type="checkbox"]').fancybutton();
    $('input[type="radio"]').fancybutton();
    });
    </script>
<?php include "inc/footer.php"?>
