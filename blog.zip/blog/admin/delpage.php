<?php 
include "lib/Session.php";
Session::checkSession();
?>
<?php
include "../config/config.php";
include "../lib/Database.php";
include "../helpers/Format.php";
?>
<?php
$db = new Database();//object
?>

<?php 
          if(!isset($_REQUEST['delpage']) or $_REQUEST['delpage'] == null){
            header('location: index.php');
          }else{
            $pageid = $_REQUEST['delpage'];
            
            ////that will delete post datas from database////
            $delquery = "DELETE from tbl_page WHERE id = $pageid";
            $delData = $db->delete($delquery);
            if($delData){
              echo "<script>alert('Data Post successfully');</script>";
              header('location: index.php');
            }else {
              echo "<script>alert('Data not Deleted');</script>";
              header('location: index.php');
            }

          }

        ?>