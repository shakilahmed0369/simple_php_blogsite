﻿<?php include "inc/header.php"?>
        <div class="grid_10">




		
            <div class="box round first grid">
                <h2>Update Copyright Text</h2>
<?php
        if(isset($_REQUEST['submit'])){
        $footer_text  = $_REQUEST['copyright'];
        if(empty($footer_text)){
            echo "<span style='color: red;'>field must not be empty</span>";
        }else{
            $query = "UPDATE tbl_footer SET footer  = '$footer_text' WHERE id = 1";
            $updated_row = $db->update($query);
            if($updated_row){
                echo "<span style='color: green;'>Footer text Update successfully</span>";
            }else{
                echo "<span style='color: red;'>Footer text Update Unsuccess</span>";

            }
        }

}

?>
                <div class="block copyblock"> 
                	
                 <form action="" method="POST">
                 <?php 
                $query = "SELECT * FROM tbl_footer WHERE id = 1";
                $show = $db->select($query);
                if($show){
                    while($result = $show->fetch_assoc()){
                ?>
                    <table class="form">					
                        <tr>
                            <td>
                                <input type="text" value="<?= $result['footer']?>" name="copyright" class="large" />
                            </td>
                        </tr>
						
						 <tr> 
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    <?php } } ?>
                    </form>
                    
                </div>
            </div>
        </div>
        <?php include "inc/footer.php"?>