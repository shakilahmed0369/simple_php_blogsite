<?php 
include "lib/Session.php";
Session::checkSession();
?>
<?php
include "../config/config.php";
include "../lib/Database.php";
include "../helpers/Format.php";
?>
<?php
$db = new Database();//object
?>

        <?php 
          if(!isset($_REQUEST['delpostid']) or $_REQUEST['delpostid'] == null){
            header('location: postlist.php');
          }else{
            $postid = $_REQUEST['delpostid'];
            ////that will delete image from main derectroy {upload __dir__ }////
            $query = "SELECT * FROM tbl_post WHERE id = $postid";
            $getdata = $db->select($query);
            if($getdata){
              while($delImg = $getdata->fetch_assoc()){
                echo $delLink = 'upload/'.$delImg['image'];
                unlink($delLink);
              }
            }
            ////that will delete post datas from database////
            $delquery = "DELETE from tbl_post WHERE id = $postid";
            $delData = $db->delete($delquery);
            if($delData){
              echo "<script>alert('Data Deleted successfully')</script>";
              header('location: postlist.php');
            }else {
              echo "<script>alert('Data not Deleted')</script>";
              header('location: postlist.php');
            }

          }

        ?>