﻿<?php include "inc/header.php"?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Category</h2>
               <div class="block copyblock"> 
                   <?php
                    if(isset($_REQUEST['submit'])){
                        $name = $_REQUEST['name'];
                        if(empty($name)){
                            echo "<span style='color: red;'>field must not be empty</span>";
                        }else{
                            $query = "INSERT INTO tbl_catagory(name) VALUES('$name')";
                            $catinsert = $db->insert($query);
                            if($catinsert){
                                echo "<span style='color: green;'>Category insurt successfully</span>";
                            }else{
                                echo "<span style='color: green;'>Category not insurted</span>";
                            }
                        }
                    }
                   ?>
                 <form action="" method="POST">
                    <table class="form">					
                        <tr>
                            <td>
                                <input name="name" type="text" placeholder="Enter Category Name..." class="medium" />
                            </td>
                        </tr>
						<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
 <?php include "inc/footer.php"?>