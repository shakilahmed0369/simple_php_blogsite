<?php include "inc/header.php"?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Post</h2>
                <?php 
                  if(!isset($_REQUEST['editpostid']) or $_REQUEST['editpostid'] == null){
                    header('location: postlist.php');
                  }else{
                    $postid = $_REQUEST['editpostid'];
                  }
                ?>
                <?php
                    if(isset($_REQUEST['submit'])){
                        $title  = $_REQUEST['title'];
                        $cat    = $_REQUEST['cat'];
                        $body   = $_REQUEST['body'];
                        $tags   = $_REQUEST['tags'];
                        $author = $_REQUEST['author'];
                        $userid = $_REQUEST['userid'];

                        $file_name = $_FILES['image']['name'];
                        $file_temp = $_FILES['image']['tmp_name'];
                        $uniq_name = uniqid().'.jpg';
                        

                        if(empty($title) || empty($cat) || empty($body) || empty($tags) || empty($author)){
                            echo "<span style='color: red;'>field must not be empty</span>";
                        }elseif(!empty($file_name)){

                            move_uploaded_file($file_temp, 'upload/'.$uniq_name);
                            $query = "UPDATE tbl_post SET
                                cat    = '$cat',
                                title  = '$title',
                                body   = '$body',
                                image  = '$uniq_name',
                                author = '$author',
                                tags   = '$tags',
                                userid   = '$userid'
                                WHERE id = $postid
                                
                            ";
                            $updated_row = $db->update($query);
                            if($updated_row){
                                echo "<span style='color: green;'>Post Update successfully</span>";
                            }else{
                                echo "<span style='color: red;'>Post Update Unsuccess</span>";

                            }

                        }else {
                            $query = "UPDATE tbl_post SET
                                cat    = '$cat',
                                title  = '$title',
                                body   = '$body',
                                author = '$author',
                                tags   = '$tags',
                                userid   = '$userid'
                                WHERE id = $postid";
                            $updated_row = $db->update($query);
                            if($updated_row){
                                echo "<span style='color: green;'>Post Update successfully</span>";
                            }else{
                                echo "<span style='color: red;'>Post Update Unsuccess</span>";
                            }
                        }
                    }
                
                ?>
                <div class="block"> 
                  <?php
                    $query = "SELECT * FROM tbl_post where id=$postid order by id desc";
                    $post = $db->select($query);
                    while($post_result = $post->fetch_assoc()){
                    ?>

                    
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input value="<?= $post_result['title']?>" name="title" type="text" placeholder="Enter Post Title..." class="medium" />
                            </td>
                        </tr>
                     
                        <tr>
                            <td>
                                <label>Category</label>
                            </td>
                            <td>
                                <select name="cat" id="select" name="select">
                                    <option>Select Catagory</option>
                                    <?php
                                     $query = "SELECT * FROM tbl_catagory";
                                     $category = $db->select($query);
                                     if($category){
                                         while($result = $category->fetch_assoc()){
                                             ?>

                                    <option
                                    <?php 
                                      if($post_result['cat'] == $result['id']){
                                        echo "selected";
                                      }
                                    ?>
                                    value="<?= $result['id']?>"><?= $result['name']?></option>

                                    <?php
                                         }
                                     }
                                    ?>

                                </select>
                            </td>
                        </tr>
                   
                        <tr>
                          
                            <td>
                                <label>Upload Image</label>
                            </td>
                            <td>
                            <img src="upload/<?= $post_result['image']?>" alt="" height="100px" width="150px"><br>
                                <input name="image" type="file" />
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea name="body" class="tinymce">
                                <?= $post_result['body']?>
                                </textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>tags</label>
                            </td>
                            <td>
                                <input value="<?= $post_result['tags']?>" name="tags" type="text" placeholder="tags" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Author</label>
                            </td>
                            <td>
                                <input value="<?= $post_result['author']?>" name="author" type="text" placeholder="author name" class="medium" />
                                <input name="userid" type="hidden" value="<?= Session::get('userid')?>" placeholder="author name" class="medium" />
                            </td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php
                    }
                  ?>              
                </div>
            </div>
        </div>
        <!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
    $(document).ready(function () {
    setupTinyMCE();
    setDatePicker('date-picker');
    $('input[type="checkbox"]').fancybutton();
    $('input[type="radio"]').fancybutton();
    });
    </script>
<?php include "inc/footer.php"?>
