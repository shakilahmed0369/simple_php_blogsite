<?php include "inc/header.php"?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>User Details</h2>
                <div class="block"> 
                <?php 
                  if(!isset($_REQUEST['viewid']) or $_REQUEST['viewid'] == null){
                    //header('location: userlist.php');
                    echo "problem found";
                  }else{
                    $viewid = $_REQUEST['viewid'];
                  }
                ?>
                  <?php
                    $query = "SELECT * FROM tbl_user WHERE id='$viewid'";
                    $getuser = $db->select($query);
                    if($getuser){
                      while($result = $getuser->fetch_assoc()){
                    
                      ?>

                    
                 <form action="" method="POST">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input value="<?= $result['name']?>" name="name" type="text" placeholder="Enter Post Title..." class="medium" />
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label>User Name</label>
                            </td>
                            <td>
                                <input value="<?= $result['username']?>" name="username" type="text" placeholder="Enter Post Title..." class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Email</label>
                            </td>
                            <td>
                                <input value="<?= $result['email']?>" name="eamil" type="text" placeholder="Enter Post Title..." class="medium" />
                            </td>
                        </tr>
                     
                   
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea name="details" class="tinymce">
                                <?= $result['details']?>
                                </textarea>
                            </td>
                        </tr>
                       
						            <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php
                    } }
                  ?>              
                </div>
            </div>
        </div>
        <!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
    $(document).ready(function () {
    setupTinyMCE();
    setDatePicker('date-picker');
    $('input[type="checkbox"]').fancybutton();
    $('input[type="radio"]').fancybutton();
    });
    </script>
<?php include "inc/footer.php"?>
