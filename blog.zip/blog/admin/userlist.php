
<?php include "inc/header.php"?>			 
			 <div class="grid_10">
            <div class="box round first grid">
								<h2>Category List</h2>
								<?php 
									if(isset($_REQUEST['delid'])){
										$delid = $_REQUEST['delid'];
										$delquery = "DELETE FROM tbl_user WHERE id = $delid";
										$deluser = $db->delete($delquery);
										if($deluser){
											echo "<span style='color: green;'>User Deleted successfully</span>";
										}else{
											echo "<span style='color: green;'>User not Deleted</span>";
									}
									}
								?>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Name</th>
							<th>User Name</th>
							<th>Email</th>
							<th>Dtails</th>
							<th>Role</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$query = "SELECT * FROM tbl_user ORDER BY id DESC";
							$alluser = $db->select($query);
							if($alluser){
								$i=0;
								while($result = $alluser->fetch_assoc()){
								$i++;
								?>
										<tr class="odd gradeX">
											<td><?= $i ?></td>
											<td><?= $result['name']?></td>
											<td><?= $result['username']?></td>
											<td><?= $result['email']?></td>
											<td><?= $fm->textShorten($result['details'], 20)?></td>
                      <td><?php
                      if($result['role'] == 0){
                        echo "Admin";
                      }elseif($result['role'] == 1){
                        echo "Author";
                      }elseif($result['role'] == 2){
                        echo "Editor";
                      }
                      ?></td>
											<td><a href="viewuser.php?viewid=<?=$result['id']?>">Viwe User</a> || <a href="?delid=<?=$result['id']?>" onclick="return confirm('are you sure?')">Delete</a></td>
										</tr>

								<?php
								}
							}
						?>

					</tbody>
				</table>
               </div>
            </div>
				</div>

<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();

        $('.datatable').dataTable();
        setSidebarHeight();
    });
</script>

<?php include "inc/footer.php"?>