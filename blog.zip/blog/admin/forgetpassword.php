<?php
include "lib/Session.php";
Session::init();
include "../config/config.php";
include "../lib/Database.php";
include "../helpers/Format.php";

?>
<?php
//object
$db = new Database();
$fm = new Format();

?>
<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Login</title>
    <link rel="stylesheet" type="text/css" href="css/stylelogin.css" media="screen" />
</head>
<body>
<div class="container">
	<section id="content">
		<?php 
      if(isset($_REQUEST['submit'])){
       $email = $_REQUEST['email'];

        $query = "SELECT * FROM tbl_user WHERE email = '$email'";
        $emailcheck = $db->select($query);
        if(mysqli_num_rows($emailcheck)>0){
          while($result = $emailcheck->fetch_assoc()){
            $userid = $result['id'];
            $username = $result['username'];
          }
          $text = substr($email, 0, 3);
          $rand = rand(1000,9999);
          $newpass = "$text$rand";
          ///////////////////////
          ///////////////////////
          ///////////////////////
          ///UNDER CONSTRUCTION//
          ///////////////////////
          ///////////////////////
          ///////////////////////
          ///////////////////////
        }
      }
?>
		<form action="" method="POST">

			<h1>RECOVER PASSWORD</h1>
			<div>
				<input type="text" placeholder="Your Email" required="" name="email"/>
			</div>
			<div>
				<input type="submit" value="SEND" name="submit"/>
			</div>
		</form><!-- form -->
		<div class="button">
			<a href="#">Training with live project</a>
		</div><!-- button -->
	</section><!-- content -->
</div><!-- container -->
</body>
</html>