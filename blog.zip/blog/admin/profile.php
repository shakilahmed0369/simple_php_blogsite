<?php include "inc/header.php"?>
<?php 
  $userid = Session::get('userid');
  $userrole = Session::get('role');    
?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Post</h2>

                <?php
                    if(isset($_REQUEST['submit'])){
                        $username  = $_REQUEST['username'];
                        $name    = $_REQUEST['name'];
                        $email   = $_REQUEST['email'];
                        $details   = $_REQUEST['details'];

                            $query = "UPDATE tbl_user SET
                                username    = '$username',
                                name  = '$name',
                                email   = '$email',
                                details = '$details'
                                WHERE id = $userid";
                            $updated_row = $db->update($query);
                            if($updated_row){
                                echo "<span style='color: green;'>User Update successfully</span>";
                            }else{
                                echo "<span style='color: red;'>User Update Unsuccess</span>";
                            }
                        }
                ?>
                <div class="block"> 
                  <?php
                    $query = "SELECT * FROM tbl_user WHERE id='$userid' and role = '$userrole'";
                    $getuser = $db->select($query);
                    if($getuser){
                      while($result = $getuser->fetch_assoc()){
                    
                      ?>

                    
                 <form action="" method="POST">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input value="<?= $result['name']?>" name="name" type="text" placeholder="Enter Post Title..." class="medium" />
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label>User Name</label>
                            </td>
                            <td>
                                <input value="<?= $result['username']?>" name="username" type="text" placeholder="Enter Post Title..." class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Email</label>
                            </td>
                            <td>
                                <input value="<?= $result['email']?>" name="email" type="text" placeholder="Enter Post Title..." class="medium" />
                            </td>
                        </tr>
                     
                   
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea name="details" class="tinymce">
                                <?= $result['details']?>
                                </textarea>
                            </td>
                        </tr>
                       
						            <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php
                    } }
                  ?>              
                </div>
            </div>
        </div>
        <!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
    $(document).ready(function () {
    setupTinyMCE();
    setDatePicker('date-picker');
    $('input[type="checkbox"]').fancybutton();
    $('input[type="radio"]').fancybutton();
    });
    </script>
<?php include "inc/footer.php"?>
