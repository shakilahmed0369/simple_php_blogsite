<?php include "inc/header.php"?>
<?php


if(!isset($_REQUEST['msgid']) || $_REQUEST['msgid'] == NULL){
  echo "<script>window.location = 'inbox.php';</script>";
}else{
  $id = $_REQUEST['msgid'];
}
?>

<?php
   if(isset($_REQUEST['submit'])){
    $to = $_REQUEST['toEmail'];
    $from = $_REQUEST['fromEmail'];
    $subject = $_REQUEST['subject'];
    $body = $_REQUEST['body'];
    $sendmail = mail($to, $subject, $body, $from);
    if($sendmail){
        echo "<span style='color: green;'>Email send successfully</span>";
    }else {
        echo "<span style='color: red;'>Email send unsuccessful</span>";
    }
   }

?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Message</h2>
                <?php 
                  $query = "SELECT * FROM tbl_contact WHERE id = $id";
                  $msg = $db->select($query);
                  if($msg){
                    while($result = $msg->fetch_assoc()){
								?>
                <div class="block">               
                 <form action="" method="POST"">
                    <table class="form">
                        <tr>
                            <td>
                                <label>To</label>
                            </td>
                            <td>
                                <input readonly name="toEmail" type="text" value="<?= $result['email']?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>From</label>
                            </td>
                            <td>
                                <input name="fromEmail" type="text" placeholder="please inter your emil address" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Subject</label>
                            </td>
                            <td>
                                <input name="subject" type="text" class="medium" />
                            </td>
                        </tr>
                     
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Message</label>
                            </td>
                            <td>
                                <textarea name="body" class="tinymce"></textarea>
                            </td>
                        </tr>

						            <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="SEND" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php } } ?>
                </div>
            </div>
        </div>
        <!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
    $(document).ready(function () {
    setupTinyMCE();
    setDatePicker('date-picker');
    $('input[type="checkbox"]').fancybutton();
    $('input[type="radio"]').fancybutton();
    });
    </script>
<?php include "inc/footer.php"?>
