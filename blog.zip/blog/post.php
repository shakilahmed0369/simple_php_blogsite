<?php include "inc/header.php"?>
<?php
	if(!isset($_GET['id']) || $_GET['id'] == NULL){
		header('location: 404.php');
	}else{
		$id =	$_GET['id'];
	}
?>
	<div class="contentsection contemplete clear">
		<div class="maincontent clear">
			<div class="about">
				<?php
					$query = "SELECT * FROM tbl_post WHERE id = $id";
					$post = $db->select($query);
					if($post){
						while($result = $post->fetch_assoc()){ ?>
				<h2><?= $result['title']?></h2>
				<h4><?= $fm->formatDate($result['date'])?></h4>
				<img src="admin/upload/<?= $result['image']?>" alt="post image"/>
							
				<?= $result['body']?>	
				<?php $catid = $result['cat']?>
				<?php
						}
						?>

				
				
				<div class="relatedpost clear">
				<h2>Related articles</h2>
					<?php
						$queryCat = "SELECT * FROM tbl_post WHERE cat = $catid LIMIT 6";
					$relted_post = $db->select($queryCat);
					if($relted_post){
						while($rresult = $relted_post->fetch_assoc()){ ?>
					<a href="post.php?id=<?= $rresult['id']?>"><img src="admin/upload/<?php echo $rresult['image']?>" alt="post image"/></a>

					<?php } 
						
					}else{
								echo "NO related post";
						} ?>

				</div>
				<?php
					}else{
						header('location: 404.php');
					}
						
				?>
	</div>

		</div>
		<?php include "inc/sidebar.php"?>
	</div>

	<?php include "inc/footer.php"?>