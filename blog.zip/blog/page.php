<?php include "inc/header.php"?>

<?php


?>

	<div class="contentsection contemplete clear">
		<div class="maincontent clear">
			<div class="about">
			<?php 
			if(!isset($_REQUEST['pageid']) or $_REQUEST['pageid'] == NULL){
				header('location: 404.php');
			}else{
				$pageid = $_REQUEST['pageid'];
			}
       $query = "SELECT * FROM tbl_page WHERE id = $pageid";
       $pages = $db->select($query);
       if($pages){
       while($result = $pages->fetch_object()){
       ?>
				<h2><?= $result->name?></h2>
				<?= $result->body?>
		</div>
			 <?php } } ?>
		</div>
		<?php include "inc/sidebar.php"?>	
		</div>
	</div>
		<?php include "inc/footer.php"?>